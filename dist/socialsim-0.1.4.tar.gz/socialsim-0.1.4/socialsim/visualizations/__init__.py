#from .JOSH_FILL_THIS_IN import generate_plot

# just here so everything imports properly. Remove once generate plot is defined
def generate_plot():
    pass
