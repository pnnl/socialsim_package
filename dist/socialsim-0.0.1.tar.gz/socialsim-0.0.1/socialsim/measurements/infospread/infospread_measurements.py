from infospread_node       import InfospreadNode
from infospread_population import InfospreadPopulation
from infospread_community  import InfospreadCommunity

class InfospreadMeasurements(InfospreadNode, InfospreadPopulation,
    InfospreadCommunity):

    def __init__():
