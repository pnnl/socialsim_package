from ..record import RecordKeeper




class MeasurementsBaseClass:
    def __init__(self, dataset, configuration, log_file='measurements_log.txt'):
        """
        Description:

        Input:
            :dataset:
            :configuration:

        Output:
        """

        self.dataset       = dataset
        self.configuration = configuration
        self.timer = RecordKeeper('measurements_log.txt')
        self.functions = {}

    def run(self, measurements_subset=None, timing=False):
        """
        Description:

        Input:
            :measurements_subset:
            :timing:

        Output:
            :results:
            :logs:

        """
        results = {}
        logs    = {}

        for scale in configuration.keys():
            scale_results = {}
            scale_logs    = {}

            for name in configuration[scale].keys():
                result, log = _evaluate_measurement(configuration[scale][name],
                    timing)

                scale_results.update({'name':result})
                scale_logs.update({'name':log})

            results.update({scale:scale_results})
            logs.update({scale:scale_logs})

        return results, logs

    def _evaluate_measurement(self, configuration, timing):
        """
        Description: Evaluates

        Input:
            :configuration:
            :timing:

        Output:
            :result:
            :log:
        """
        log = {}

        # unpack the configuration dictionary
        function_name      = configuration['measurement']
        function_arguments = configuration['measurement_args']

        # get the requested method from the instantiated measurement class
        function = getattr(self, function_name)

        # Evaluate the function with the given arguments
        self.timer.tic(1)

        try:
            result = function(**function_arguments)
        except Exception as error:
            result = function_name+' failed to run.'
            log.update({'Error': error})

        delta_time = self.timer.toc(1)

        log.update({'run_time': delta_time})

        return result, log

    def add_measurement(self, function):

        self.functions.update({function.__name__:function})

        return function
