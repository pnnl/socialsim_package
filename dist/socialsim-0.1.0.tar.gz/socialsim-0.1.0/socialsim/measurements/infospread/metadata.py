class InfospreadMetaData:

    def __init__(content_data, user_data):
        """
        Description:

        Input:

        Output:

        """
