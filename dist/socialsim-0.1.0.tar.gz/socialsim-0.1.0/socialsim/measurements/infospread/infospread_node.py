from ..measurements import MeasurementsBaseClass

class InfospreadNode:
    def __init__(self):
        """
        Description: Intentially does nothing. Infospread parent classes are
            just containers for functions. That is all.

        Input:
            None

        Output:
            None
        """
        pass
