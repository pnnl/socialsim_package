from ..measurements import MeasurementsBaseClass

class InfospreadNode(MeasurementsBaseClass):
    def __init__(self):
        pass
