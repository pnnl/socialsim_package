class InfospreadNode:
    def __init__(self):
        pass
