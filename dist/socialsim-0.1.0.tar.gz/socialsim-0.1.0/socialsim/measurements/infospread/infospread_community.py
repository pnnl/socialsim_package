class InfospreadCommunity:
    def __init__(self):
        pass
