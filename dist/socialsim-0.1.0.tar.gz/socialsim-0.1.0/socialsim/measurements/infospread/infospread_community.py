from ..measurements import MeasurementsBaseClass

class InfospreadCommunity(MeasurementsBaseClass):
    def __init__(self):
        pass
