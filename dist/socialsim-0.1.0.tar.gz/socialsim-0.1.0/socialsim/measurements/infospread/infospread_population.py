from ..measurements import MeasurementsBaseClass

class InfospreadPopulation(MeasurementsBaseClass):
    def __init__(self):
        pass
