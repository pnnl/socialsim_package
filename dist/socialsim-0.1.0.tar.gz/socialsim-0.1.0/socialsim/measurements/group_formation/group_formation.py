class GroupFormationMeasurements:
    def __init__(self):
        pass
