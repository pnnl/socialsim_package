from ..measurements import MeasurementsBaseClass

class GroupFormationMeasurements(MeasurementsBaseClass):
    def __init__(self):
        pass
