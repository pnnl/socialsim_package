from ..measurements import MeasurementsBaseClass

class CrossPlatformMeasurements(MeasurementsBaseClass):
    def __init__(self):
        pass
